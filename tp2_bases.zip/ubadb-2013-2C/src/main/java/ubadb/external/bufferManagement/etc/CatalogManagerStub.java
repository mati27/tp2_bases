package ubadb.external.bufferManagement.etc;

public class CatalogManagerStub
{

}
