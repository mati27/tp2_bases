package ubadb.core.components.catalogManager;

import java.util.List;


/**
 * Serializable class that represents the catalog
 * 
 */
public class Catalog
{
	private List<TableDescriptor> tableDescriptors;
}
