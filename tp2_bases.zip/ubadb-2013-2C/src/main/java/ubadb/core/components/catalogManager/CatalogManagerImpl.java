package ubadb.core.components.catalogManager;

import ubadb.core.common.TableId;

//TODO Complete
public class CatalogManagerImpl implements CatalogManager
{
	@Override
	public TableDescriptor getTableDescriptorByTableId(TableId tableId)
	{
		// TODO Complete
		return null;
	}
}
