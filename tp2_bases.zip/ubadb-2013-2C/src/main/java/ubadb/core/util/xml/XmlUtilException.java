package ubadb.core.util.xml;

@SuppressWarnings("serial")
public class XmlUtilException extends Exception
{
	public XmlUtilException(String message, Exception e)
	{
		super(message,e);
	}
}
