package ubadb.core.util;

public class TestUtil
{
	public static final long PAUSE_INTERVAL = 50L;
}
